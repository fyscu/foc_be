<?php
require_once 'config.php';
header('Content-Type: text/html; charset=utf-8');
// 获取订单ID
$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// 如果没有订单ID，显示错误
if (!$order_id) {
    echo "<div class='error'>无效的订单ID</div>";
    exit;
}

// 获取订单信息
try {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("
        SELECT o.*, t.name as technician_name, t.phone as technician_phone
        FROM fyd_orders o
        LEFT JOIN fyd_technicians t ON o.technician_id = t.id
        WHERE o.id = :order_id
    ");
    $stmt->execute([':order_id' => $order_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$order) {
        echo "<div class='error'>订单不存在</div>";
        exit;
    }
    
    // 检查订单状态
    if ($order['status'] !== 'processing') {
        echo "<div class='error'>该订单当前不在维修中状态，无法填写维修记录</div>";
        exit;
    }
} catch (Exception $e) {
    echo "<div class='error'>系统错误: " . $e->getMessage() . "</div>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>技术员维修记录 - <?php echo htmlspecialchars($order['order_number']); ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background-color: #f3f4f6;
        }
        .container {
            max-width: 800px;
        }
        .error {
            color: #ef4444;
            padding: 1rem;
            margin: 1rem;
            background-color: #fee2e2;
            border-radius: 0.375rem;
            text-align: center;
        }
        .success {
            color: #10b981;
            padding: 1rem;
            margin: 1rem;
            background-color: #d1fae5;
            border-radius: 0.375rem;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container mx-auto px-4 py-8">
        <div class="bg-white rounded-lg shadow-lg p-6 mb-6">
            <h1 class="text-2xl font-bold text-gray-800 mb-4">技术员维修记录</h1>
            <div class="border-b pb-4 mb-4">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <p class="text-sm text-gray-600">订单编号</p>
                        <p class="font-medium"><?php echo htmlspecialchars($order['order_number']); ?></p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">客户姓名</p>
                        <p class="font-medium"><?php echo htmlspecialchars($order['customer_name']); ?></p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">设备类型</p>
                        <p class="font-medium"><?php echo htmlspecialchars($order['device_type']); ?> <?php echo htmlspecialchars($order['device_model'] ?? ''); ?></p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">故障描述</p>
                        <p class="font-medium"><?php echo nl2br(htmlspecialchars($order['problem_description'])); ?></p>
                    </div>
                </div>
            </div>
            
            <form id="repairForm" class="space-y-6">
                <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
                
                <!-- 技术员信息 -->
                <div>
                    <h3 class="text-lg font-semibold text-gray-800 mb-3">技术员信息</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">技术员姓名</label>
                            <input type="text" name="technician1_name" value="<?php echo htmlspecialchars($order['technician_name'] ?? ''); ?>" readonly
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">联系方式</label>
                            <input type="text" name="technician1_phone" value="<?php echo htmlspecialchars($order['technician_phone'] ?? ''); ?>" readonly
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-50">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">接手时间</label>
                            <input type="datetime-local" name="technician1_time" required
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        </div>
                    </div>
                </div>
                
                <!-- 故障诊断 -->
                <div>
                    <h3 class="text-lg font-semibold text-gray-800 mb-3">故障诊断</h3>
                    <textarea name="diagnosis" rows="4" required
                              placeholder="请详细描述故障诊断结果..."
                              class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
                </div>
                
                <!-- 解决方案 -->
                <div>
                    <h3 class="text-lg font-semibold text-gray-800 mb-3">解决方案</h3>
                    <textarea name="solution" rows="4" required
                              placeholder="请详细描述解决方案..."
                              class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
                </div>
                
                <!-- 技术员签名 -->
                <div>
                    <h3 class="text-lg font-semibold text-gray-800 mb-3">技术员签名确认</h3>
                    <div id="signatureCanvas" class="border border-gray-300 rounded-md h-40 bg-gray-50 flex items-center justify-center">
                        <canvas id="technicianSignature" width="400" height="150" class="cursor-crosshair"></canvas>
                    </div>
                    <input type="hidden" name="technician_signature" id="technicianSignatureData">
                    <div class="flex justify-end mt-2">
                        <button type="button" id="clearSignature" class="text-sm text-blue-600 hover:text-blue-800">
                            清除签名
                        </button>
                    </div>
                </div>
                
                <!-- 提交按钮 -->
                <div class="flex justify-end space-x-4 pt-6 border-t">
                    <button type="submit" 
                            class="px-6 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">
                        提交维修记录
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // 初始化签名画布
            initSignatureCanvas();
            
            // 表单提交处理
            document.getElementById('repairForm').addEventListener('submit', async function(e) {
                e.preventDefault();
                
                // 获取表单数据
                const formData = new FormData(e.target);
                const repairData = Object.fromEntries(formData.entries());
                
                // 验证签名
                if (!repairData.technician_signature) {
                    showMessage('请完成签名确认', 'error');
                    return;
                }
                
                try {
                    // 提交维修记录
                    const response = await fetch('update_repair_record.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(repairData)
                    });
                    
                    const result = await response.json();
                    
                    if (result.success) {
                        showMessage('维修记录已提交，订单状态已更新为待取机', 'success');
                        
                        // 禁用表单
                        const form = document.getElementById('repairForm');
                        const inputs = form.querySelectorAll('input, textarea, button');
                        inputs.forEach(input => input.disabled = true);
                        
                        // 3秒后关闭页面
                        setTimeout(() => {
                            window.close();
                        }, 3000);
                    } else {
                        showMessage('提交失败: ' + result.message, 'error');
                    }
                } catch (error) {
                    console.error('提交维修记录失败:', error);
                    showMessage('提交失败，请重试', 'error');
                }
            });
        });
        
        // 初始化签名画布
        function initSignatureCanvas() {
            const canvas = document.getElementById('technicianSignature');
            const ctx = canvas.getContext('2d');
            const signatureInput = document.getElementById('technicianSignatureData');
            
            let isDrawing = false;
            let lastX = 0;
            let lastY = 0;
            
            // 设置画布样式
            ctx.lineWidth = 2;
            ctx.lineCap = 'round';
            ctx.lineJoin = 'round';
            ctx.strokeStyle = '#000';
            
            // 鼠标/触摸事件
            canvas.addEventListener('mousedown', startDrawing);
            canvas.addEventListener('touchstart', handleTouch(startDrawing));
            
            canvas.addEventListener('mousemove', draw);
            canvas.addEventListener('touchmove', handleTouch(draw));
            
            canvas.addEventListener('mouseup', stopDrawing);
            canvas.addEventListener('touchend', handleTouch(stopDrawing));
            canvas.addEventListener('mouseout', stopDrawing);
            
            // 清除签名按钮
            document.getElementById('clearSignature').addEventListener('click', function() {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                signatureInput.value = '';
            });
            
            function startDrawing(e) {
                isDrawing = true;
                [lastX, lastY] = [e.offsetX, e.offsetY];
            }
            
            function draw(e) {
                if (!isDrawing) return;
                
                ctx.beginPath();
                ctx.moveTo(lastX, lastY);
                ctx.lineTo(e.offsetX, e.offsetY);
                ctx.stroke();
                
                [lastX, lastY] = [e.offsetX, e.offsetY];
                
                // 保存签名数据
                signatureInput.value = canvas.toDataURL();
            }
            
            function stopDrawing() {
                isDrawing = false;
            }
            
            function handleTouch(callback) {
                return function(e) {
                    e.preventDefault();
                    const touch = e.touches[0];
                    if (touch) {
                        const rect = canvas.getBoundingClientRect();
                        const offsetX = touch.clientX - rect.left;
                        const offsetY = touch.clientY - rect.top;
                        
                        const mouseEvent = new MouseEvent('mousemove', {
                            clientX: touch.clientX,
                            clientY: touch.clientY
                        });
                        
                        mouseEvent.offsetX = offsetX;
                        mouseEvent.offsetY = offsetY;
                        callback(mouseEvent);
                    }
                };
            }
        }
        
        // 显示消息
        function showMessage(message, type) {
            const container = document.querySelector('.container');
            const messageDiv = document.createElement('div');
            messageDiv.className = type;
            messageDiv.textContent = message;
            
            // 移除之前的消息
            const oldMessages = document.querySelectorAll('.error, .success');
            oldMessages.forEach(msg => msg.remove());
            
            // 添加新消息
            container.insertBefore(messageDiv, container.firstChild);
            
            // 自动消失
            if (type !== 'error') {
                setTimeout(() => {
                    messageDiv.remove();
                }, 5000);
            }
        }
    </script>
</body>
</html>
<?php
require_once 'config.php';

try {
    $pdo = getDBConnection();
    
    // 获取当前活动的订单统计
    $sql = "
        SELECT 
            status,
            COUNT(*) as count
        FROM fyd_orders o
        LEFT JOIN fyd_activities a ON o.activity_id = a.id
        WHERE a.is_current = 1
        GROUP BY status
    ";
    
    $stmt = $pdo->query($sql);
    $results = $stmt->fetchAll();
    $sql = "
        SELECT 
            COUNT(*)
        FROM fyd_orders o
        LEFT JOIN fyd_activities a ON o.activity_id = a.id
        WHERE a.is_current = 1
    ";
    
    $stmt = $pdo->query($sql);
    $totalresults = $stmt->fetchColumn();
    
    // 初始化统计数据
    $stats = [
        'total' => 0,
        'pending' => 0,
        'processing' => 0,
        'ready' => 0,
        'completed' => 0
    ];
    
    // 填充实际数据
    foreach ($results as $row) {
        $stats[$row['status']] = (int)$row['count'];
    }
    $stats['total'] = (int)$totalresults;
    sendResponse(true, $stats);
    
} catch (Exception $e) {
    sendResponse(false, null, '获取统计数据失败: ' . $e->getMessage());
}
?>
// 主应用程序逻辑
class App {
    constructor() {
        this.currentPage = 'dashboard';
        this.currentUser = null;
        this.orderEntry = null;
        this.workflow = null;
        this.screenDisplay = null;
        this.technicianMgmt = null;
        this.smsNotification = null;
    }

    init() {
        // 初始化工作流管理器
        this.workflow = new WorkflowManager(this);
        
        // 初始化大屏显示管理器
        this.screenDisplay = new ScreenDisplay(this);
        
        // 初始化技术员管理器
        this.technicianMgmt = new TechnicianManagement(this);
        
        // 初始化短信通知管理器
        this.smsNotification = new SMSNotification(this);
        
        this.bindEvents();
        this.loadPage('dashboard');
        this.updateDashboard();
        
        // 每30秒刷新一次数据
        setInterval(() => {
            if (this.currentPage === 'dashboard') {
                this.updateDashboard();
            }
        }, 30000);
    }

    bindEvents() {
        // 侧边栏切换
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        
        sidebarToggle?.addEventListener('click', () => {
            sidebar.classList.toggle('-translate-x-full');
        });

        // 导航菜单点击事件
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const page = item.getAttribute('data-page');
                this.loadPage(page);
                
                // 更新活跃状态
                document.querySelectorAll('.nav-item').forEach(nav => {
                    nav.classList.remove('bg-blue-100', 'text-blue-600');
                    nav.classList.add('text-gray-700');
                });
                item.classList.add('bg-blue-100', 'text-blue-600');
                item.classList.remove('text-gray-700');
            });
        });

        // 退出登录
        document.getElementById('logoutBtn')?.addEventListener('click', () => {
            if (confirm('确定要退出登录吗？')) {
                this.logout();
            }
        });
    }

    loadPage(pageName) {
        this.currentPage = pageName;
        const pageContent = document.getElementById('pageContent');
        
        // 隐藏所有页面内容
        document.querySelectorAll('.page-content').forEach(page => {
            page.style.display = 'none';
        });

        // 显示对应页面或加载新页面
        let targetPage = document.getElementById(pageName);
        if (targetPage) {
            targetPage.style.display = 'block';
        } else {
            // 动态加载页面内容
            this.loadPageContent(pageName);
        }
    }

    async loadPageContent(pageName) {
        const pageContent = document.getElementById('pageContent');
        
        try {
            let content = '';
            
            switch (pageName) {
                case 'order-entry':
                    content = Pages.getOrderEntryPage();
                    break;
                case 'order-management':
                    content = Pages.getOrderManagementPage();
                    break;
                case 'technician-screen':
                    content = Pages.getTechnicianScreenPage();
                    break;
                case 'service-screen':
                    content = Pages.getServiceScreenPage();
                    break;
                case 'technician-management':
                    content = Pages.getTechnicianManagementPage();
                    break;
                case 'activity-management':
                    content = Pages.getActivityManagementPage();
                    break;
                default:
                    content = '<h2 class="text-2xl font-bold text-gray-800">页面未找到</h2>';
            }
            
            pageContent.innerHTML = content;
            
            // 绑定页面特定的事件
            this.bindPageEvents(pageName);
            
        } catch (error) {
            console.error('加载页面失败:', error);
            pageContent.innerHTML = '<h2 class="text-2xl font-bold text-red-600">页面加载失败</h2>';
        }
    }

    bindPageEvents(pageName) {
        switch (pageName) {
            case 'order-entry':
                this.bindOrderEntryEvents();
                break;
            case 'order-management':
                this.bindOrderManagementEvents();
                break;
            case 'technician-screen':
                this.bindTechnicianScreenEvents();
                break;
            case 'service-screen':
                this.bindServiceScreenEvents();
                break;
            case 'technician-management':
                this.bindTechnicianManagementEvents();
                break;
        }
    }

    bindOrderEntryEvents() {
        // 初始化订单录入模块
        if (!this.orderEntry) {
            this.orderEntry = new OrderEntry(this);
        }
        
        const form = document.getElementById('orderForm');
        const positionSelect = document.getElementById('position');
        const orderNumberInput = document.getElementById('orderNumber');
        const resetBtn = document.getElementById('resetForm');
        const submitNextBtn = document.getElementById('submitAndNext');
        
        if (form) {
            form.addEventListener('submit', async (e) => {
                e.preventDefault();
                await this.orderEntry.submitOrder(form, false);
            });
        }
        
        // 位置选择变化时更新订单编号
        if (positionSelect) {
            positionSelect.addEventListener('change', async (e) => {
                const position = e.target.value;
                if (position) {
                    await this.orderEntry.updateOrderNumber(position);
                }
            });
        }
        
        // 重置表单
        if (resetBtn) {
            resetBtn.addEventListener('click', () => {
                form.reset();
                orderNumberInput.value = '';
            });
        }
        
        // 提交并添加下一个
        if (submitNextBtn) {
            submitNextBtn.addEventListener('click', async (e) => {
                e.preventDefault();
                await this.orderEntry.submitOrder(form, true);
            });
        }
        
        // 初始化功能
        this.orderEntry.updateNextNumbers();
        this.orderEntry.bindKeyboardShortcuts();
        this.orderEntry.bindCharacterCount();
    }

    bindOrderManagementEvents() {
        // 订单管理页面事件绑定
        this.loadOrders();
    }

    bindTechnicianScreenEvents() {
        // 技术员大屏事件绑定
        this.screenDisplay.initTechnicianScreen();
    }

    bindServiceScreenEvents() {
        // 客服大屏事件绑定
        this.screenDisplay.initServiceScreen();
    }

    bindTechnicianManagementEvents() {
        // 技术员管理页面事件绑定
        this.technicianMgmt.init();
    }

    async updateDashboard() {
        try {
            const stats = await API.getOrderStats();
            if (stats.success) {
                const data = stats.data;
                document.getElementById('pendingCount').textContent = data.pending || 0;
                document.getElementById('processingCount').textContent = data.processing || 0;
                document.getElementById('readyCount').textContent = data.ready || 0;
                document.getElementById('completedCount').textContent = data.completed || 0;
            }
        } catch (error) {
            console.error('更新控制台数据失败:', error);
        }
    }

    async loadOrders() {
        try {
            const result = await API.getOrders();
            if (result.success) {
                this.renderOrderList(result.data.orders);
            }
        } catch (error) {
            console.error('加载订单失败:', error);
        }
    }

    renderOrderList(orders) {
        const container = document.getElementById('orderList');
        if (!container) return;

        const html = orders.map(order => {
            const nextStatuses = this.workflow.getStatusConfig(order.status)?.next || [];
            
            return `
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    ${order.order_number}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ${order.customer_name}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ${order.customer_phone}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ${order.device_type}
                </td>
                <td class="px-6 py-4 whitespace-nowrap">
                    ${this.workflow.renderStatusBadge(order.status)}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ${order.created_at}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div class="flex justify-end space-x-2">
                        <button class="text-blue-600 hover:text-blue-900" onclick="app.viewOrder('${order.id}')" title="查看详情">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="text-gray-600 hover:text-gray-900" onclick="app.workflow.showStatusHistory('${order.id}')" title="状态历史">
                            <i class="fas fa-history"></i>
                        </button>
                        ${nextStatuses.length > 0 ? `
                        <button class="text-green-600 hover:text-green-900" onclick="app.showStatusMenu('${order.id}', '${order.status}')" title="更改状态">
                            <i class="fas fa-edit"></i>
                        </button>
                        ` : ''}
                        ${order.status === 'ready' ? `
                        <button class="text-purple-600 hover:text-purple-900" onclick="app.smsNotification.showSMSDialog('${order.id}')" title="发送短信">
                            <i class="fas fa-sms"></i>
                        </button>
                        ` : ''}
                    </div>
                </td>
            </tr>
            `;
        }).join('');

        container.innerHTML = html || '<tr><td colspan="7" class="px-6 py-4 text-center text-gray-500">暂无订单</td></tr>';
    }

    getStatusText(status) {
        return this.workflow ? this.workflow.getStatusName(status) : status;
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 ${
            type === 'success' ? 'bg-green-500 text-white' :
            type === 'error' ? 'bg-red-500 text-white' :
            'bg-blue-500 text-white'
        }`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }

    logout() {
        // 清除用户数据
        this.currentUser = null;
        // 重定向到登录页面或刷新页面
        window.location.reload();
    }

    async viewOrder(orderId) {
        try {
            const result = await API.getOrderById(orderId);
            if (result.success) {
                this.showOrderModal(result.data);
            }
        } catch (error) {
            console.error('获取订单详情失败:', error);
            this.showNotification('获取订单详情失败', 'error');
        }
    }

    showOrderModal(order) {
        const modalHtml = `
            <div class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50" id="orderModal">
                <div class="relative top-20 mx-auto p-5 border w-11/12 md:w-3/4 lg:w-1/2 shadow-lg rounded-md bg-white">
                    <div class="mt-3">
                        <div class="flex justify-between items-center mb-4">
                            <h3 class="text-lg font-medium text-gray-900">订单详情 - ${order.order_number}</h3>
                            <button onclick="document.getElementById('orderModal').remove()" 
                                    class="text-gray-400 hover:text-gray-600">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <h4 class="font-medium text-gray-700 mb-2">客户信息</h4>
                                <p><strong>姓名：</strong>${order.customer_name}</p>
                                <p><strong>电话：</strong>${order.customer_phone}</p>
                                <p><strong>QQ：</strong>${order.customer_qq || '未填写'}</p>
                            </div>
                            <div>
                                <h4 class="font-medium text-gray-700 mb-2">设备信息</h4>
                                <p><strong>类型：</strong>${order.device_type}</p>
                                <p><strong>型号：</strong>${order.device_model || '未填写'}</p>
                                <p><strong>状态：</strong>${this.workflow.renderStatusBadge(order.status)}</p>
                            </div>
                        </div>
                        <div class="mt-4">
                            <h4 class="font-medium text-gray-700 mb-2">故障描述</h4>
                            <p class="text-gray-600">${order.problem_description}</p>
                        </div>
                        ${order.accessories ? `
                        <div class="mt-4">
                            <h4 class="font-medium text-gray-700 mb-2">配件情况</h4>
                            <p class="text-gray-600">${order.accessories}</p>
                        </div>
                        ` : ''}
                        ${order.notes ? `
                        <div class="mt-4">
                            <h4 class="font-medium text-gray-700 mb-2">备注</h4>
                            <p class="text-gray-600">${order.notes}</p>
                        </div>
                        ` : ''}
                        <div class="mt-6 flex justify-end space-x-3">
                            ${order.status === 'ready' ? `
                            <button onclick="app.smsNotification.showSMSDialog('${order.id}')" 
                                    class="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700">
                                发送短信
                            </button>
                            ` : ''}
                            <button onclick="document.getElementById('orderModal').remove()" 
                                    class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400">
                                关闭
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.getElementById('modalContainer').innerHTML = modalHtml;
    }

    // 显示状态更改菜单
    showStatusMenu(orderId, currentStatus) {
        const statusConfig = this.workflow.getStatusConfig(currentStatus);
        const nextStatuses = statusConfig?.next || [];
        
        if (nextStatuses.length === 0) {
            this.showNotification('当前状态无法进行更改', 'info');
            return;
        }

        const menuHtml = `
            <div class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50" id="statusMenu">
                <div class="relative top-20 mx-auto p-5 border w-80 shadow-lg rounded-md bg-white">
                    <div class="mt-3">
                        <h3 class="text-lg font-medium text-gray-900 mb-4">选择新状态</h3>
                        <div class="space-y-2">
                            ${nextStatuses.map(status => {
                                const config = this.workflow.getStatusConfig(status);
                                return `
                                <button onclick="app.workflow.showStatusTransitionDialog('${orderId}', '${currentStatus}', '${status}')" 
                                        class="w-full text-left px-4 py-2 rounded-md hover:bg-gray-100 border border-gray-200">
                                    ${this.workflow.renderStatusBadge(status)}
                                </button>
                                `;
                            }).join('')}
                        </div>
                        <div class="mt-4 flex justify-end">
                            <button onclick="document.getElementById('statusMenu').remove()" 
                                    class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400">
                                取消
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.getElementById('modalContainer').innerHTML = menuHtml;
    }

    // 显示技术员分配模态框
    async showAssignModal(orderId) {
        try {
            const result = await API.getTechnicians();
            if (result.success) {
                this.renderAssignModal(orderId, result.data);
            }
        } catch (error) {
            console.error('获取技术员列表失败:', error);
            this.showNotification('获取技术员列表失败', 'error');
        }
    }

    renderAssignModal(orderId, technicians) {
        const onlineTechnicians = technicians.filter(tech => tech.status === 'online');
        
        const modalHtml = `
            <div class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50" id="assignModal">
                <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
                    <div class="mt-3">
                        <h3 class="text-lg font-medium text-gray-900 mb-4">分配技术员</h3>
                        <div class="space-y-2 max-h-60 overflow-y-auto">
                            ${onlineTechnicians.map(tech => `
                                <button onclick="app.assignTechnician('${orderId}', '${tech.id}')" 
                                        class="w-full text-left px-4 py-2 rounded-md hover:bg-blue-50 border border-gray-200">
                                    <div class="flex justify-between items-center">
                                        <div>
                                            <p class="font-medium">${tech.name}</p>
                                            <p class="text-sm text-gray-500">${tech.specialty || '通用维修'}</p>
                                        </div>
                                        <span class="text-sm text-gray-400">当前: ${tech.current_orders || 0}单</span>
                                    </div>
                                </button>
                            `).join('')}
                        </div>
                        ${onlineTechnicians.length === 0 ? '<p class="text-center text-gray-500 py-4">暂无在线技术员</p>' : ''}
                        <div class="mt-4 flex justify-end">
                            <button onclick="document.getElementById('assignModal').remove()" 
                                    class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400">
                                取消
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.getElementById('modalContainer').innerHTML = modalHtml;
    }

    // 分配技术员
    async assignTechnician(orderId, technicianId) {
        try {
            const result = await API.assignTechnician(orderId, technicianId);
            if (result.success) {
                this.showNotification('技术员分配成功', 'success');
                document.getElementById('assignModal').remove();
                this.workflow.refreshRelatedViews();
            } else {
                this.showNotification('分配失败：' + result.message, 'error');
            }
        } catch (error) {
            console.error('分配技术员失败:', error);
            this.showNotification('分配技术员失败', 'error');
        }
    }

    // 显示转单模态框
    async showTransferModal(orderId) {
        try {
            const orderResult = await API.getOrderById(orderId);
            const techResult = await API.getTechnicians();
            
            if (orderResult.success && techResult.success) {
                this.renderTransferModal(orderId, orderResult.data, techResult.data);
            }
        } catch (error) {
            console.error('获取转单信息失败:', error);
            this.showNotification('获取转单信息失败', 'error');
        }
    }

    renderTransferModal(orderId, order, technicians) {
        const availableTechnicians = technicians.filter(tech => 
            tech.status === 'online' && tech.id != order.technician_id
        );

        const modalHtml = `
            <div class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50" id="transferModal">
                <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
                    <div class="mt-3">
                        <h3 class="text-lg font-medium text-gray-900 mb-4">转单操作</h3>
                        <p class="text-sm text-gray-600 mb-4">
                            当前技术员：<span class="font-medium">${order.technician_name || '未分配'}</span>
                        </p>
                        <div class="space-y-2 max-h-60 overflow-y-auto">
                            ${availableTechnicians.map(tech => `
                                <button onclick="app.transferOrder('${orderId}', '${order.technician_id}', '${tech.id}')" 
                                        class="w-full text-left px-4 py-2 rounded-md hover:bg-orange-50 border border-gray-200">
                                    <div class="flex justify-between items-center">
                                        <div>
                                            <p class="font-medium">${tech.name}</p>
                                            <p class="text-sm text-gray-500">${tech.specialty || '通用维修'}</p>
                                        </div>
                                        <span class="text-sm text-gray-400">当前: ${tech.current_orders || 0}单</span>
                                    </div>
                                </button>
                            `).join('')}
                        </div>
                        ${availableTechnicians.length === 0 ? '<p class="text-center text-gray-500 py-4">暂无可转单的技术员</p>' : ''}
                        <div class="mt-4 flex justify-end">
                            <button onclick="document.getElementById('transferModal').remove()" 
                                    class="px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400">
                                取消
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        document.getElementById('modalContainer').innerHTML = modalHtml;
    }

    // 转单操作
    async transferOrder(orderId, fromTechnicianId, toTechnicianId) {
        try {
            const result = await API.transferOrder(orderId, fromTechnicianId, toTechnicianId);
            if (result.success) {
                this.showNotification('转单成功', 'success');
                document.getElementById('transferModal').remove();
                this.workflow.refreshRelatedViews();
            } else {
                this.showNotification('转单失败：' + result.message, 'error');
            }
        } catch (error) {
            console.error('转单失败:', error);
            this.showNotification('转单失败', 'error');
        }
    }
}

// 等待DOM加载完成后初始化应用
document.addEventListener('DOMContentLoaded', function() {
    window.app = new App();
    app.init();
});
// 大屏显示功能管理
class ScreenDisplay {
    constructor(app) {
        this.app = app;
        this.refreshInterval = null;
        this.refreshRate = 10000; // 10秒刷新一次
    }

    // 通用初始化方法
    init() {
        console.log('初始化大屏显示管理器...');
        // 等待DOM元素渲染完成后再初始化
        setTimeout(() => {
            // 根据当前页面类型初始化对应的大屏
            if (this.app.currentPage === 'technician-screen') {
                this.initTechnicianScreen();
            } else if (this.app.currentPage === 'service-screen') {
                this.initServiceScreen();
            }
        }, 100);
    }

    // 初始化6号位技术员大屏
    initTechnicianScreen() {
        this.loadTechnicianScreenData();
        this.startAutoRefresh('technician');
        
        // 绑定事件
        this.bindTechnicianScreenEvents();
    }

    // 初始化5号位客服大屏
    initServiceScreen() {
        this.loadServiceScreenData();
        this.startAutoRefresh('service');
        
        // 绑定事件
        this.bindServiceScreenEvents();
    }

    // 加载技术员大屏数据 (6号位 - 只处理待接单的订单)
    async loadTechnicianScreenData() {
        try {
            console.log('开始加载6号位技术员大屏数据...');
            
            // 6号位只需要获取待接单的订单 (pending)
            const ordersResult = await API.getOrders({ 
                status: 'pending',
                limit: 100 
            });
            console.log('6号位待接单订单API返回:', ordersResult);
            
            // 获取技术员列表
            const techniciansResult = await API.getTechnicians();
            console.log('技术员列表API返回:', techniciansResult);
            
            // 获取统计数据
            const statsResult = await API.getOrderStats();
            console.log('统计数据API返回:', statsResult);

            if (ordersResult.success && techniciansResult.success && statsResult.success) {
                const orders = ordersResult.data.orders || ordersResult.data || [];
                console.log('6号位解析的待接单订单数据:', orders);
                console.log('6号位待接单订单数量:', orders.length);
                
                this.renderTechnicianScreen(
                    orders, 
                    techniciansResult.data,
                    statsResult.data
                );
            } else {
                console.error('6号位大屏API调用失败:', {
                    orders: ordersResult,
                    technicians: techniciansResult,
                    stats: statsResult
                });
            }
        } catch (error) {
            console.error('加载6号位大屏数据失败:', error);
        }
    }

    // 加载客服大屏数据 (5号位 - 处理维修中和待取机的订单)
    async loadServiceScreenData() {
        try {
            console.log('开始加载5号位客服大屏数据...');
            
            // 5号位需要获取维修中的订单 (processing)
            const processingOrdersResult = await API.getOrders({ 
                status: 'processing',
                limit: 100 
            });
            console.log('5号位维修中订单API返回:', processingOrdersResult);
            
            // 5号位需要获取待取机的订单 (ready)
            const readyOrdersResult = await API.getOrders({ 
                status: 'ready',
                limit: 100 
            });
            console.log('5号位待取机订单API返回:', readyOrdersResult);

            // 获取统计数据
            const statsResult = await API.getOrderStats();
            console.log('5号位统计数据API返回:', statsResult);

            if (processingOrdersResult.success && readyOrdersResult.success && statsResult.success) {
                const processingOrders = processingOrdersResult.data.orders || processingOrdersResult.data || [];
                const readyOrders = readyOrdersResult.data.orders || readyOrdersResult.data || [];
                
                console.log('5号位解析的维修中订单:', processingOrders);
                console.log('5号位解析的待取机订单:', readyOrders);
                console.log('5号位维修中订单数量:', processingOrders.length);
                console.log('5号位待取机订单数量:', readyOrders.length);
                
                this.renderServiceScreen(
                    processingOrders,
                    readyOrders,
                    statsResult.data
                );
            } else {
                console.error('5号位大屏API调用失败:', {
                    processingOrders: processingOrdersResult,
                    readyOrders: readyOrdersResult,
                    stats: statsResult
                });
            }
        } catch (error) {
            console.error('加载5号位大屏数据失败:', error);
        }
    }

    // 渲染技术员大屏 (6号位 - 只显示待接单订单)
    renderTechnicianScreen(orders, technicians, stats) {
        // 更新统计数据
        const pendingCount = document.getElementById('techPendingCount');
        const onlineTechCount = document.getElementById('onlineTechCount');

        if (pendingCount) pendingCount.textContent = orders.length; // 直接使用待接单订单数量
        if (onlineTechCount) {
            const onlineCount = technicians.filter(t => t.status === 'online').length;
            onlineTechCount.textContent = onlineCount;
        }

        // 渲染待接单订单列表
        const container = document.getElementById('techOrderList');
        if (!container) return;

        if (orders.length === 0) {
            container.innerHTML = '<tr><td colspan="6" class="px-6 py-4 text-center text-gray-500">暂无待接单订单</td></tr>';
            return;
        }

        const html = orders.map(order => `
            <tr class="hover:bg-gray-50 bg-yellow-50">
                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    <div class="flex items-center">
                        <span class="text-lg font-bold text-yellow-600">
                            ${order.order_number}
                        </span>
                        <span class="ml-2 inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                            待接单
                        </span>
                    </div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    <div>
                        <div class="font-medium">${order.customer_name}</div>
                        <div class="text-gray-500">${order.customer_phone}</div>
                    </div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <div>
                        <div class="font-medium">${order.device_type}</div>
                        <div class="text-xs text-gray-400">${order.device_brand || '未知品牌'}</div>
                    </div>
                </td>
                <td class="px-6 py-4 text-sm text-gray-500 max-w-xs">
                    <div class="truncate" title="${order.problem_description}">
                        ${order.problem_description}
                    </div>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    ${order.created_at}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button onclick="app.showAssignModal('${order.id}')" 
                            class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded text-sm font-medium">
                        分配技术员
                    </button>
                </td>
            </tr>
        `).join('');

        container.innerHTML = html;
    }

    // 渲染客服大屏 (5号位 - 显示维修中和待取机订单)
    renderServiceScreen(processingOrders, readyOrders, stats) {
        // 更新统计数据
        const processingCount = document.getElementById('serviceProcessingCount');
        const readyCount = document.getElementById('serviceReadyCount');

        if (processingCount) processingCount.textContent = processingOrders.length;
        if (readyCount) readyCount.textContent = readyOrders.length;

        // 渲染订单列表 - 分为维修中和待取机两个部分
        const container = document.getElementById('serviceOrderList');
        if (!container) return;

        // 维修中订单部分
        const processingHtml = processingOrders.length > 0 ? `
            <div class="mb-6">
                <h3 class="text-lg font-semibold text-blue-600 mb-3 border-b border-blue-200 pb-2">
                    维修中订单 (${processingOrders.length})
                </h3>
                <div class="space-y-2">
                    ${processingOrders.map(order => `
                        <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                            <div class="flex justify-between items-center">
                                <div class="flex-1">
                                    <div class="flex items-center space-x-3">
                                        <span class="text-lg font-bold text-blue-600">${order.order_number}</span>
                                        <span class="text-sm text-gray-600">${order.customer_name}</span>
                                        <span class="text-sm text-gray-500">${order.customer_phone}</span>
                                        <span class="text-sm text-gray-500">${order.device_type}</span>
                                    </div>
                                    <div class="mt-1 text-xs text-gray-500">
                                        技术员: ${order.technician_name || '未分配'} | 开始时间: ${order.updated_at}
                                    </div>
                                </div>
                                <div class="flex space-x-2">
                                    <button onclick="app.workflow.showStatusTransitionDialog('${order.id}', 'processing', 'ready')" 
                                            class="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-sm">
                                        标记完成
                                    </button>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        ` : '';

        // 待取机订单部分
        const readyHtml = readyOrders.length > 0 ? `
            <div>
                <h3 class="text-lg font-semibold text-orange-600 mb-3 border-b border-orange-200 pb-2">
                    待取机订单 (${readyOrders.length})
                </h3>
                <div class="space-y-2">
                    ${readyOrders.map(order => `
                        <div class="bg-orange-50 border border-orange-200 rounded-lg p-4">
                            <div class="flex justify-between items-center">
                                <div class="flex-1">
                                    <div class="flex items-center space-x-3">
                                        <span class="text-lg font-bold text-orange-600">${order.order_number}</span>
                                        <span class="text-sm font-medium text-gray-900">${order.customer_name}</span>
                                        <span class="text-sm font-medium text-gray-900">${order.customer_phone}</span>
                                        <span class="text-sm text-gray-600">${order.device_type}</span>
                                    </div>
                                    <div class="mt-1 text-xs text-gray-500">
                                        完成时间: ${order.updated_at} | 技术员: ${order.technician_name || '未知'}
                                    </div>
                                </div>
                                <div class="flex space-x-2">
                                    <button onclick="app.screenDisplay.showSMSQRCode('${order.id}', '${order.customer_phone}', '${order.customer_name}', '${order.order_number}')" 
                                            class="bg-purple-600 hover:bg-purple-700 text-white px-3 py-1 rounded text-sm ${order.sms_sent == 1 ? 'opacity-50' : ''}"
                                            title="${order.sms_sent == 1 ? '短信已发送' : '点击显示短信二维码'}">
                                        ${order.sms_sent == 1 ? '已标记发送' : '去发送短信'}
                                    </button>

                                    <button onclick="app.workflow.showStatusTransitionDialog('${order.id}', 'sms_sent', 'completed')" 
                                            class="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-sm">
                                        取件
                                    </button>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        ` : '';

        // 如果没有任何订单
        if (processingOrders.length === 0 && readyOrders.length === 0) {
            container.innerHTML = '<div class="text-center text-gray-500 py-8">暂无订单</div>';
            return;
        }

        container.innerHTML = processingHtml + readyHtml;
    }

    // 绑定技术员大屏事件
    bindTechnicianScreenEvents() {
        // 添加快捷键支持
        document.addEventListener('keydown', (e) => {
            if (this.app.currentPage !== 'technician-screen') return;
            
            // F5 刷新
            if (e.key === 'F5') {
                e.preventDefault();
                this.loadTechnicianScreenData();
            }
            
            // 空格键暂停/恢复自动刷新
            if (e.code === 'Space') {
                e.preventDefault();
                this.toggleAutoRefresh();
            }
        });
    }

    // 绑定客服大屏事件
    bindServiceScreenEvents() {
        // 添加快捷键支持
        document.addEventListener('keydown', (e) => {
            if (this.app.currentPage !== 'service-screen') return;
            
            // F5 刷新
            if (e.key === 'F5') {
                e.preventDefault();
                this.loadServiceScreenData();
            }
            
            // 空格键暂停/恢复自动刷新
            if (e.code === 'Space') {
                e.preventDefault();
                this.toggleAutoRefresh();
            }
        });
    }

    // 开始自动刷新
    startAutoRefresh(screenType) {
        this.stopAutoRefresh(); // 先停止之前的刷新
        
        this.refreshInterval = setInterval(() => {
            if (screenType === 'technician' && this.app.currentPage === 'technician-screen') {
                this.loadTechnicianScreenData();
            } else if (screenType === 'service' && this.app.currentPage === 'service-screen') {
                this.loadServiceScreenData();
            }
        }, this.refreshRate);
    }

    // 停止自动刷新
    stopAutoRefresh() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
            this.refreshInterval = null;
        }
    }

    // 切换自动刷新
    toggleAutoRefresh() {
        if (this.refreshInterval) {
            this.stopAutoRefresh();
            this.app.showNotification('自动刷新已暂停，按空格键恢复', 'info');
        } else {
            const screenType = this.app.currentPage === 'technician-screen' ? 'technician' : 'service';
            this.startAutoRefresh(screenType);
            this.app.showNotification('自动刷新已恢复', 'success');
        }
    }

    // 设置刷新频率
    setRefreshRate(rate) {
        this.refreshRate = rate * 1000; // 转换为毫秒
        
        // 如果正在刷新，重新启动
        if (this.refreshInterval) {
            const screenType = this.app.currentPage === 'technician-screen' ? 'technician' : 'service';
            this.startAutoRefresh(screenType);
        }
    }

    // 全屏显示
    enterFullscreen() {
        const element = document.documentElement;
        if (element.requestFullscreen) {
            element.requestFullscreen();
        } else if (element.webkitRequestFullscreen) {
            element.webkitRequestFullscreen();
        } else if (element.msRequestFullscreen) {
            element.msRequestFullscreen();
        }
    }

    // 退出全屏
    exitFullscreen() {
        if (document.exitFullscreen) {
            document.exitFullscreen();
        } else if (document.webkitExitFullscreen) {
            document.webkitExitFullscreen();
        } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
        }
    }

    // 显示短信二维码
    async showSMSQRCode(orderId, phone, customerName, orderNumber) {
        // 构建短信内容
        var ua = navigator.userAgent;
        const smsContent = `【飞扬俱乐部】您好${customerName}，您的设备（订单号：${orderNumber}）已维修完成，请及时到现场取回。如有疑问请联系我们。`;
        
        // 构建短信URL（适用于iOS和Android）
        // const smsUrl = `sms:${phone}?body=${encodeURIComponent(smsContent)}`;
        let smsUrl = `sms:${phone}&body=${encodeURIComponent(smsContent)}`;
        if (/(iPhone|iPad|iPod|iOS)/i.test(ua)) {
	        smsUrl = `sms:${phone}&body=${encodeURIComponent(smsContent)}`;
        } else {
            smsUrl = `sms:${phone}?body=${encodeURIComponent(smsContent)}`;
        }
        // 创建模态框
        const modal = document.createElement('div');
        modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
        modal.innerHTML = `
            <div class="bg-white rounded-lg p-6 max-w-md w-full mx-4">
                <div class="text-center">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">扫码发送短信</h3>
                    <div class="mb-4">
                        <p class="text-sm text-gray-600 mb-2">订单号：${orderNumber}</p>
                        <p class="text-sm text-gray-600 mb-2">客户：${customerName}</p>
                        <p class="text-sm text-gray-600 mb-4">手机：${phone}</p>
                    </div>
                    
                    <!-- 二维码容器 -->
                    <div id="qrcode-container" class="flex justify-center mb-4">
                        <div class="w-48 h-48 border-2 border-gray-300 rounded-lg flex items-center justify-center">
                            <p id="qrp">二维码加载中...</p>
                            <div id="qrcode-${orderId}"></div>
                        </div>
                    </div>
                    
                    <div class="text-xs text-gray-500 mb-4 px-4">
                        <p class="mb-2">短信内容：</p>
                        <p class="bg-gray-100 p-2 rounded text-left">${smsContent}</p>
                    </div>
                    
                    <div class="text-sm text-blue-600 mb-4">
                        <p>请使用手机扫描二维码</p>
                        <p>自动打开短信应用发送通知</p>
                    </div>
                    
                    <div class="flex space-x-3">
                        <button onclick="this.parentElement.parentElement.parentElement.parentElement.remove()" 
                                class="flex-1 bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded">
                            关闭
                        </button>
                        <button onclick="app.screenDisplay.markSMSSent('${orderId}'); this.parentElement.parentElement.parentElement.parentElement.remove();" 
                                class="flex-1 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded">
                            标记已发送
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        
        // 生成二维码
        this.generateQRCode(`qrcode-${orderId}`, smsUrl);
        // 取消qrp的显示
        const qrPlaceholder = document.getElementById('qrp');
        if (qrPlaceholder) {
            qrPlaceholder.style.display = 'none';
        }
            
        // 点击背景关闭
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
    }

    // 生成二维码
    generateQRCode(containerId, text) {
        // 使用简单的二维码生成方法
        // 这里使用在线二维码API服务
        const qrContainer = document.getElementById(containerId);
        if (qrContainer) {
            const qrUrl = `https://api.pwmqr.com/qrcode/create/?url=${encodeURIComponent(text)}`;
            qrContainer.innerHTML = `<img src="${qrUrl}" alt="短信二维码" class="w-full h-full object-contain" />`;
        }
    }

    // 标记短信已发送
    async markSMSSent(orderId) {
        try {
            console.log('标记订单短信已发送:', orderId);
            
            // 调用API标记短信已发送
            const result = await API.markSMSSent(orderId);
            
            if (result.success) {
                this.app.showNotification('短信发送状态已更新', 'success');
                // 刷新当前页面数据
                if (this.app.currentPage === 'service-screen') {
                    this.loadServiceScreenData();
                }
            } else {
                this.app.showNotification('更新失败：' + (result.message || '未知错误'), 'error');
            }
        } catch (error) {
            console.error('标记短信发送状态失败:', error);
            this.app.showNotification('标记失败，请重试', 'error');
        }
    }

    // 销毁大屏显示
    destroy() {
        this.stopAutoRefresh();
    }
}
